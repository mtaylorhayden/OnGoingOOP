﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TheaterEngine;

namespace TheaterConsole
{
    public class Program
    {
        /// <summary>
        /// The theater for the console.
        /// </summary>
        private Theater theater;

        static void Main(string[] args)
        {
            Console.Title = "2.2 Theater Test";

            Console.WriteLine("Welcome to the Marcus Theater!");

            Theater theater = Theater.NewTheater();

            string command;

            bool exit = false;

            while(!exit)
            {
                Console.Write("]");

                // Type something, the command variable catches it.
                command = Console.ReadLine();

                // Switches depending on what has been typed in.
                switch (command)
                {
                    // If new is typed.
                    case "new":
                        // Create the screening room.
                        ScreeningRoom screeningRoom = new ScreeningRoom(true, 78);

                        // Create a new instance of the theater.
                        theater = new Theater("Marcus Theater", screeningRoom, 450m, 5m, 4m);

                        // Writes the following message to the user.
                        Console.WriteLine("A new Marcus Theater was created");

                        break;

                    // If exit is typed.
                    case "exit":
                        exit = true;

                        break;
                    // If count is typed.
                    case "count":

                        Console.WriteLine($"Movies: {theater.Movies.Count()}");

                        Console.WriteLine($"Guests: {theater.Guests.Count()}");

                        break;
                }
            }
        }
    }
}
