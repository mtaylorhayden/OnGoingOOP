﻿using System;
using System.Collections.Generic;
using ConcessionItems;
using Stands;

namespace TheaterEngine
{
    /// <summary>
    /// The class that represents a guest.
    /// </summary>
    public class Guest
    {
        /// <summary>
        /// The guest's age.
        /// </summary>
        private int age;

        /// <summary>
        /// The guest's list of purchased concession items.
        /// </summary>
        private List<ConcessionItem> concessionItems;

        /// <summary>
        /// The title of the movie the guest wants to see.
        /// </summary>
        private string desiredMovieTitle;

        /// <summary>
        /// The guest's list of movies seen.
        /// </summary>
        private List<Movie> moviesSeen;

        /// <summary>
        /// The guest's preferred soda flavor.
        /// </summary>
        private SodaFlavor preferredSodaFlavor;

        /// <summary>
        /// The guest's wallet.
        /// </summary>
        private Wallet wallet;

        /// <summary>
        /// Initializes a new instance of the Guest class.
        /// </summary>
        /// <param name="age">The guest's age.</param>
        /// <param name="desiredMovieTitle">The title of the movie the guest wants to see.</param>
        /// <param name="preferredSodaFlavor">The guest's preferred soda flavor.</param>
        /// <param name="wallet">The guest's wallet.</param>
        public Guest(int age, string desiredMovieTitle, SodaFlavor preferredSodaFlavor, Wallet wallet)
        {
            this.age = age;
            this.concessionItems = new List<ConcessionItem>();
            this.desiredMovieTitle = desiredMovieTitle;
            this.moviesSeen = new List<Movie>();
            this.preferredSodaFlavor = preferredSodaFlavor;
            this.wallet = wallet;
        }

        /// <summary>
        /// Gets or sets the guest's age.
        /// </summary>
        public int Age
        {
            get
            {
                return this.age;
            }

            set
            {
                if(this.age > 100 && this.age < 0)
                {
                    throw new ArgumentOutOfRangeException("Age cannot be less than 0 or greater than 100");
                }
                else
                {
                    this.age = value;
                }
            }
        }

        /// <summary>
        /// Gets or sets the title of the movie the guest wants to see.
        /// </summary>
        public string DesiredMovieTitle
        {
            get
            {
                return this.desiredMovieTitle;
            }

            set
            {
                if(this.desiredMovieTitle.Length < 1 && this.desiredMovieTitle.Length > 100)
                {
                    throw new ArgumentOutOfRangeException("Desired movie length cannot be less than one or greater than 100 characters.");
                }
                else
                {
                    this.desiredMovieTitle = value;
                }
            }
        }

        /// <summary>
        /// Gets the guest's wallet's money balance.
        /// </summary>
        public decimal MoneyBalance
        {
            get
            {
                return this.wallet.MoneyBalance;
            }
        }

        /// <summary>
        /// Gets or sets the guest's preferred soda flavor.
        /// </summary>
        public SodaFlavor PreferredSodaFlavor
        {
            get
            {
                return this.preferredSodaFlavor;
            }

            set
            {
                this.preferredSodaFlavor = value;
            }
        }

        /// <summary>
        /// Gets the guest's wallet.
        /// </summary>
        public Wallet Wallet
        {
            get
            {
                return this.wallet;
            }
        }

        /// <summary>
        /// Adds a movie to the guest's list of movies seen.
        /// </summary>
        /// <param name="movie">The movie to add.</param>
        public void AddMovieSeen(Movie movie)
        {
            this.moviesSeen.Add(movie);
        }

        /// <summary>
        /// Buys concessions.
        /// </summary>
        /// <param name="popcornStand">The stand from which to purchase popcorn.</param>
        /// <param name="sodaCupStand">The stand from which to purchase a soda cup.</param>
        /// <param name="sodaStand">The stand from which to fill a soda cup.</param>
        public void BuyConcessions(PopcornStand popcornStand, SodaCupStand sodaCupStand, SodaStand sodaStand)
        {
            // Buy popcorn
            Popcorn popcorn = this.BuyPopcorn(popcornStand);

            // Buy soda
            SodaCup sodaCup = this.BuySoda(sodaCupStand, sodaStand);

            if(popcorn != null)
            {
                this.concessionItems.Add(popcorn);
            }

            if(sodaCup != null)
            {
                this.concessionItems.Add(sodaCup);
            }

            // Consume the concession items.
            foreach (ConcessionItem ci in this.concessionItems)
            {
                ci.Consume();
            }
        }

        /// <summary>
        /// Creates a string representation of a guest.
        /// </summary>
        /// <returns>The specified string.</returns>
        public override string ToString()
        {
            return $"Wants to see: {this.DesiredMovieTitle} (Age: {this.Age})";
        }

        /// <summary>
        /// Buys a bag of popcorn.
        /// </summary>
        /// <param name="popcornStand">The stand from which to purchase the popcorn.</param>
        /// <returns>The bag of popcorn.</returns>
        private Popcorn BuyPopcorn(PopcornStand popcornStand)
        {
            // Define result variable.
            Popcorn popcorn = null;

            // The price of the popcorn.
            decimal popcornPrice = popcornStand.ItemPrice;

            // Removes the amount the popcorn costs.
            decimal amountRemoved = wallet.RemoveMoney(popcornPrice);

            // Buys popcorn from the popcorn stand.
            popcorn = popcornStand.BuyPopcorn(amountRemoved);

            if(popcorn != null)
            {
                // Add butter and salt.
                popcorn.AddButter();
                popcorn.AddSalt();
                popcorn.AddSalt();
            }

            // Return result
            return popcorn;
        }

        /// <summary>
        /// Buys a cup of soda.
        /// </summary>
        /// <param name="sodaCupStand">The stand from which to purchase the cup.</param>
        /// <param name="sodaStand">The stand from which to purchase the soda.</param>
        /// <returns>The cup of soda.</returns>
        private SodaCup BuySoda(SodaCupStand sodaCupStand, SodaStand sodaStand)
        {
            // Define result variable
            SodaCup sodaCup = null;

            // Gets the price of the soda cup.
            decimal sodaCupPrice = sodaCupStand.ItemPrice;

            // Removes money from the wallet to buy a sodacup.
            decimal amountRemoved = wallet.RemoveMoney(sodaCupPrice);

            // Buy a sodacup.
            sodaCup = sodaCupStand.BuySodaCup(amountRemoved);

            // Fill the cup with soda.
            this.FillSoda(sodaCup, sodaStand);

            // Return result
            return sodaCup;
        }

        /// <summary>
        /// Fills a soda cup.
        /// </summary>
        /// <param name="sodaCup">The cup to fill.</param>
        /// <param name="sodaStand">The stand from which to fill the cup.</param>
        private void FillSoda(SodaCup sodaCup, SodaStand sodaStand)
        {
            // Fill the soda cup
            sodaStand.FillSodaCup(sodaCup, this.preferredSodaFlavor);
        }
    }
}