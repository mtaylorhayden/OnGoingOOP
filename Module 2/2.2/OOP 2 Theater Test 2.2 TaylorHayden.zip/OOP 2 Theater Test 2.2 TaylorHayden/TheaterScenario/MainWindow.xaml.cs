﻿using ConcessionItems;
using MoneyCollectors;
using System;
using System.Windows;
using TheaterEngine;

namespace TheaterScenario
{
    /// <summary>
    /// Contains interaction logic for MainWindow.xaml.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.StyleCop.CSharp.NamingRules", "SA1300:ElementMustBeginWithUpperCaseLetter", Justification = "Event handlers may begin with lower-case letters.")]
    public partial class MainWindow : Window
    {
        /// <summary>
        /// The Marcus Theater.
        /// </summary>
        private Theater marcusTheater;

        /// <summary>
        /// Initializes a new instance of the MainWindow class.
        /// </summary>
        public MainWindow()
        {
            this.InitializeComponent();
        }

        /// <summary>
        /// 
        /// </summary>
        private void PopulateGuestListBox()
        {
            this.guestListBox.ItemsSource = null;

            // Populate the list box with the list of guests.
            this.guestListBox.ItemsSource = this.marcusTheater.Guests;
        }

        /// <summary>
        /// 
        /// </summary>
        private void PopulateMovieListBox()
        {
            this.movieListBox.ItemsSource = null;

            // Populate list box with the list of movies.
            this.movieListBox.ItemsSource = this.marcusTheater.Movies;
        }

        /// <summary>
        /// The event that initially loads the window.
        /// </summary>
        /// <param name="sender">The object that initiated the event.</param>
        /// <param name="e">The event arguments for the event.</param>
        private void window_Loaded(object sender, RoutedEventArgs e)
        {
            // Set the marcus theater field to the New theater method.
            this.marcusTheater = Theater.NewTheater();

            // Populate both list boxes.
            this.PopulateGuestListBox();
            this.PopulateMovieListBox();
        }

        /// <summary>
        /// Adds a movie to the list box.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void addMovieButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Sample movie for movie window.
                Movie movie = new Movie(false, MovieRating.G, 123, "The Matrix");

                // New movie window.
                MovieWindow movieWindow = new MovieWindow(movie);

                if (movieWindow.ShowDialog() == true)
                {
                    // Sets rating
                    movie.Rating = (MovieRating)movieWindow.ratingComboBox.SelectedItem;

                    this.marcusTheater.AddMovie(movie);

                    this.PopulateMovieListBox();
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Name must only contain letters and numberss");
            }
        }

        /// <summary>
        ///  Adds a guest to the list box.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void addGuestButton_Click(object sender, RoutedEventArgs e)
        {
            // Sample wallet and sample guest for window.
            Wallet wallet = new Wallet(WalletColor.Black, 123);
            Guest guest = new Guest(2, "The Matix", ConcessionItems.SodaFlavor.Dolt, wallet);

            // Create everything needs to buy concession stand items.
            IMoneyCollector moneyCollector = new MoneyCollector(50);
            Stands.PopcornStand popcornStand = new Stands.PopcornStand(5, moneyCollector);
            Stands.SodaCupStand sodaCupStand = new Stands.SodaCupStand(5, moneyCollector);
            Stands.SodaStand sodaStand = new Stands.SodaStand();

            // Create a new window.
            GuestWindow guestWindow = new GuestWindow(guest);

            // If a new window was created then...
            if(guestWindow.ShowDialog() == true)
            {
                // Buy concession items.
                guest.BuyConcessions(popcornStand, sodaCupStand, sodaStand);

                // Set the soda flavor.
                guest.PreferredSodaFlavor = (SodaFlavor)guestWindow.sodaFlavorComboBox.SelectedItem;

                // Set the wallet color.
                guest.Wallet.Color = (WalletColor)guestWindow.walletColorComboBox.SelectedItem;

                // Add the guest to the theater.
                this.marcusTheater.AddGuest(guest);

                // Repopulate the guest list.
                this.PopulateGuestListBox();
            }
        }
    }
}