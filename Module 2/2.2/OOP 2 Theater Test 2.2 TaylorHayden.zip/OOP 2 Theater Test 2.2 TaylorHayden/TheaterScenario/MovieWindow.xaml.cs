﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TheaterEngine;

namespace TheaterScenario
{
    /// <summary>
    /// Interaction logic for MovieWindow.xaml
    /// </summary>
    public partial class MovieWindow : Window
    {
        private Movie movie;

        public MovieWindow(Movie movie)
        {
            this.movie = movie;

            InitializeComponent();
        }

        /// <summary>
        /// When the window gets loaded...
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            this.titleTextBox.Text = this.movie.Title;

            this.runtimeTextBox.Text = this.movie.Runtime.ToString();

            this.ratingComboBox.ItemsSource = Enum.GetValues(typeof(MovieRating));

            this.is3DCheckBox.Content = true ? true : false;

        }

        /// <summary>
        /// The ok button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
        }

        /// <summary>
        /// Cancel button event handler.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }

        /// <summary>
        /// Change the title of the movie.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void titleTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            this.movie.Title = this.titleTextBox.Text;
        }

        /// <summary>
        /// Change the runtime of the movie.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void runtimeTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            this.movie.Runtime = int.Parse(this.runtimeTextBox.Text);
        }
    }
}
