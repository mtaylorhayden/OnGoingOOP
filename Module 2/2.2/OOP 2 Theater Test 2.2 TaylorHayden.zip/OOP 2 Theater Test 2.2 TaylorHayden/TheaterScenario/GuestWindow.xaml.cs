﻿using ConcessionItems;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TheaterEngine;

namespace TheaterScenario
{
    /// <summary>
    /// Interaction logic for GuestWindow.xaml
    /// </summary>
    public partial class GuestWindow : Window
    {
        private Guest guest;

        public GuestWindow(Guest guest)
        {
            this.guest = guest;
            InitializeComponent();
        }

        /// <summary>
        /// When the window loads...
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            this.ageTextBox.Text = this.guest.Age.ToString();

            this.desiredMovieTextBox.Text = this.guest.DesiredMovieTitle;

            this.sodaFlavorComboBox.ItemsSource = Enum.GetValues(typeof(SodaFlavor));

            this.walletColorComboBox.ItemsSource = Enum.GetValues(typeof(WalletColor));
        }

        /// <summary>
        /// Adds money to the guests wallet.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void addMoneyButton_Click(object sender, RoutedEventArgs e)
        {
            this.guest.Wallet.AddMoney(5);

            this.moneyBalanceLabel.Content = guest.Wallet.MoneyBalance;
        }

        /// <summary>
        /// Subtracts money from the guests wallet.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void subtractMoneyButton_Click(object sender, RoutedEventArgs e)
        {
            this.guest.Wallet.RemoveMoney(5);

            this.moneyBalanceLabel.Content = guest.Wallet.MoneyBalance;
        }

        /// <summary>
        /// The ok button.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void okButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
        }

        /// <summary>
        /// Sets the age text box.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ageTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            this.guest.Age = int.Parse(this.ageTextBox.Text);
        }

        /// <summary>
        /// Sets the desired movie.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void desiredMovieTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            this.guest.DesiredMovieTitle = this.desiredMovieTextBox.Text;
        }
    }
}
