﻿namespace People
{
    /// <summary>
    /// The class which is used to represent a piece of baggage.
    /// </summary>
    public class Baggage
    {
    }
}