﻿
namespace People
{
    public enum Gender
    {
        Female,
        Male
    }
}
